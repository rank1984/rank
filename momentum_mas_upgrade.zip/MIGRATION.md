# מה למחוק / להחליף / ליצור (מול rank-main.zip שהעלית)

## 1. מחק
| קובץ | למה |
|------|-----|
| `download` | `.gitignore` בשם שגוי; חסם את `logs/decisions.csv` ולכן הלוג לא נשמר |
| `screener.yml` (שורש) | GitHub מריץ רק מ-`.github/workflows/`. הוחלף ב-`.github/workflows/screener.yml` |
| `.github/workflows/daily-report.yml` | **של פרויקט אחר (Oracle)**: מריץ `python main.py` שלא קיים, דורש `ANTHROPIC_API_KEY` ו-`oracle_memory.db`. ייכשל כל יום ב-04:00 UTC |
| `screener_agent.py`, `catalyst_agent.py`, `risk_manager.py` (שורש) | עברו ל-`agents/` (שם `orchestrator.py` מייבא אותם) |
| `momentum_mas_v2.zip` | ארכיון ישן (אופציונלי) |

## 2. החלף (קובץ מלא)
`config.py`, `utils.py`, `orchestrator.py`, `notifier.py`, `requirements.txt`, `README.md`,
`backtest/engine.py`, `backtest/run_backtest.py`

(`backtest/run_backtest.py` הישן קרא ל-`calculate_metrics(trades, initial_capital=...)` ול-`print_report`
שלא קיימים ב-`backtest/metrics.py` הנוכחי - כלומר היה שבור.)

## 3. צור (חדש)
```
.gitignore
.github/workflows/screener.yml
agents/__init__.py
agents/filters.py          פילטרים (מקור אמת יחיד)
agents/trade_plan.py       plan_trade משותף
agents/screener_agent.py
agents/catalyst_agent.py
agents/risk_manager.py
backtest/stats.py
scripts/_stubs.py  scripts/_synthetic.py
scripts/count_signals.py  scripts/cost_ratio_grid.py  scripts/check_universe.py
scripts/run_all_tests.py
scripts/test_p0_filters.py  scripts/test_e2e_screen_ticker.py  scripts/test_trade_sim.py
scripts/test_backtest_run.py  scripts/test_count_signals.py  scripts/test_orchestrator_dryrun.py
logs/fills.csv   logs/.gitkeep
```

## 4. השאר (לא נוגעים)
`agents/sec_filter.py`, `backtest/__init__.py`, `backtest/metrics.py`, `backtest/slippage.py`,
`backtest/setups.py`, `backtest/run_intraday.py`, `universe.csv`, `env.example`, `__init__.py`

## סדר פעולות
1. ענף חדש (לא `main`).
2. מחיקות, החלפות, יצירות לפי הרשימות.
3. `pip install -r requirements.txt && python scripts/run_all_tests.py` (אמור להסתיים ב"כל הבדיקות עברו").
4. `python scripts/cost_ratio_grid.py`, ואז להגדיר `COMMISSION_PER_SIDE` ב-`config.py` (מספר אמיתי מהברוקר).
5. `python scripts/count_signals.py --days 90` (דורש רשת).
6. Push. ב-Actions: Run workflow עם `force_run=true` פעם אחת, לוודא commit של `logs/`; אחר כך Run רגיל (מחוץ לשעות ייצא `no_new_bar` - תקין).
7. מיזוג ל-`main` רק אחרי שלב 6.

אם כבר מיזגת חבילה של המומחה (`momentum_mas_p0`): לא למזג את שתיהן. לבחור אחת (שתיהן כותבות לאותם קבצים).
