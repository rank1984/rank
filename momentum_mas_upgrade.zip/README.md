# Momentum MAS v3.0-p0 - מערכת מרובת-סוכנים לאיתור מניות מומנטום (1-3 ימי החזקה)

> **מצב: מדידה, לא מסחר.** המערכת אוספת אותות ומודדת אותם. אין הוכחת Edge.
> אסור לשנות פרמטרים של האסטרטגיה עד N אותות Tier A סגורים (ראה "משמעת מדידה").

## זרימה

```
orchestrator.py
  1. prepare_session  - נר סגור? יום חג? (no_new_bar = לא נרשמים אותות)
  2. Screener         - agents/screener_agent.py + agents/filters.py (פילטרים עצמאיים, בלי elif)
  3. Catalyst         - agents/catalyst_agent.py (LLM בקריאה אחת, temperature=0)
  4. Risk             - agents/risk_manager.py + agents/trade_plan.py
  5. לוגים + טלגרם    - סיכום יומי תמיד
```

## הפרדה בין מדידה לביצוע

| שדה | משמעות |
|-----|--------|
| `approved_signal` | עבר Screener + Tier A (סיווג LLM, לא fallback). **זה מה שנמדד ל-Edge** |
| `approved_live`   | `approved_signal` + שער עלות + קיבולת (MAX_OPEN_POSITIONS, תקציב). זה מה שנשלח לביצוע |

`COMMISSION_PER_SIDE = None` (ברירת מחדל) => אין `approved_live`, והמדידה ממשיכה.

## כללי הניסוי (קפואים)

Tier A בלבד | כניסה ב-**Open של T+1** | סטופ 4% | יעד 12% | חלון 3 ימי מסחר |
שער עלות `cost_ratio <= 0.25` (קבוע) במקום שער R:R | fail-closed ל-mcap/float.
R = qty * (entry - stop), בלי עמלות. כל חישוב תוכנית עובר ב-`agents/trade_plan.plan_trade`.

## קבצי לוג (נשמרים ל-repo על ידי ה-workflow)

| קובץ | תוכן |
|------|------|
| `logs/decisions.csv` | אותות שעברו Screener (כולל נדחי Tier/עלות/קיבולת), dedupe לפי `signal_date+ticker+run_mode` |
| `logs/screener_all.csv` | כל טיקר בכל ריצה + `all_failed` (לבדיקת תרומת כל פילטר) |
| `logs/runs.csv` | שורה לכל ריצה, גם "אין אותות" וגם כישלון |
| `logs/mcap_snapshot.csv` | snapshot יומי של mcap/float (לא ניתן לשחזר בדיעבד) |
| `logs/llm_raw/` | prompt + תשובה גולמית של ה-LLM לכל ריצה |
| `logs/fills.csv` | **ממלאים ידנית**: `signal_date,ticker,side,time,qty,price,fees,status,skip_reason` |

כל עסקה שאושרה בטלגרם חייבת שורה ב-`fills.csv` (`status=filled` או `skipped` עם `skip_reason`).
`run_mode=force` (FORCE_RUN=1) לא נכנס לניתוח Edge.

## הרצה

```bash
pip install -r requirements.txt
cp env.example .env            # למלא מפתחות
python scripts/run_all_tests.py        # בדיקות offline (בלי רשת)
python scripts/cost_ratio_grid.py      # cost_ratio לפי מחיר x עמלה
python scripts/count_signals.py --days 90   # קצב מועמדים טכניים (דורש רשת)
python orchestrator.py                 # ריצה רגילה (נעצרת מחוץ לשעות/בחג)
FORCE_RUN=1 python orchestrator.py     # בדיקה בלבד
python -m backtest.run_backtest --days 365 --sens 1 2 3   # DESCRIPTIVE_ONLY
python scripts/check_universe.py       # תחזוקת יקום חודשית
```

## מגבלות ידועות

- **Backtest = DESCRIPTIVE_ONLY**: אין Tier A היסטורי, survivorship bias, mcap/float לא נקודתיים.
- Slippage (0.15% / 0.25% / 0.10%) הוא הנחה. להחליף בערכים מ-`fills.csv` אחרי 20+ fills.
- מס רווחי הון מחושב בדוח על סך הרווח בתקופה, לא לכל עסקה. לאמת עם רו"ח.
- ימי חג מזוהים דרך `no_new_bar` (הנר האחרון קודם לתאריך הצפוי), לא דרך לוח NYSE.
- VWAP: EMA20 יומי משמש תחליף למגמה, לא VWAP אמיתי.

## משמעת מדידה

מדד ראשי: Expectancy ב-R נטו אחרי עלויות. קריטריון: הגבול התחתון של bootstrap CI מעל 0.
Insider / Memory / Narrative / Post-Gap: רק shadow, לא משפיעים על אישור.

זה כלי מחקר/אוטומציה - לא ייעוץ השקעות.
