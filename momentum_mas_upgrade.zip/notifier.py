"""
התראות טלגרם. סיכום יומי נשלח *תמיד* (כדי שיום שקט לא ייראה כנפילה).
אם אין approved_live: ההודעה מסומנת "אות בלבד, לא לביצוע" עם סיבת החסימה.
"""
import html
import os
from collections import Counter

import requests

import config


def send_telegram_message(text: str):
    bot_token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    if not bot_token or not chat_id:
        print("  (טלגרם לא מוגדר - מדלג על שליחה)")
        return False
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {"chat_id": chat_id, "text": text[:4000], "parse_mode": "HTML"}
    try:
        resp = requests.post(url, json=payload, timeout=10)
        resp.raise_for_status()
        return True
    except Exception as e:  # noqa: BLE001
        print(f"  שגיאת שליחת טלגרם: {e}")
        return False


def _e(x) -> str:
    return html.escape(str(x))


def format_trade_alert(t: dict) -> str:
    stop_pct = round(config.STOP_LOSS_PCT * 100, 1)
    tp_pct = round(config.TAKE_PROFIT_LIVE_PCT * 100, 1)
    return (
        f"🎯 <b>איתות לביצוע (Tier {_e(t.get('catalyst_tier'))}): {_e(t['ticker'])}</b>\n"
        f"📅 תאריך האות: {_e(t.get('bar_date'))}\n\n"
        f"💰 סגירת האות: ${_e(t['price'])} (אינדיקציה בלבד)\n"
        f"⚠️ <b>כניסה: Open של יום המסחר הבא</b> - לא במחיר הזה.\n"
        f"🛑 סטופ: {stop_pct}% מהמחיר שנקנה בפועל | 🎯 יעד: {tp_pct}%\n"
        f"📊 גודל לפי הסגירה: {_e(t['qty'])} מניות (${_e(t['position_value'])}), "
        f"סיכון ≈ ${_e(t['risk_dollars'])}\n"
        f"   (לחשב מחדש לפי מחיר הפתיחה בפועל)\n"
        f"⚙️ cost_ratio: {_e(t.get('cost_ratio'))} | rr_potential: {_e(t.get('rr_potential_gross'))}\n\n"
        f"📈 RSI: {_e(t['rsi'])} | RVOL: {_e(t['rvol'])}x | ATR: {_e(t['atr_pct'])}%\n"
        f"💪 עוצמה יחסית: {_e(t.get('relative_strength_pct'))}% (מדד: {_e(t.get('benchmark_change_pct'))}%)\n"
        f"📰 {_e(t.get('catalyst_type', ''))} (מקור: {_e(t.get('classifier_source'))})\n\n"
        f"🕐 חלון: עד {config.HOLDING_DAYS_MAX} ימי מסחר\n"
        f"📝 לרשום fill או skipped ב-logs/fills.csv"
    )


def format_run_summary(meta: dict, results: list) -> str:
    status = meta.get("status")
    mode = meta.get("run_mode", "live")
    head = f"🔍 <b>סריקה</b> | נר: {_e(meta.get('session_date'))} | מצב: {_e(mode)}"

    if status == "no_new_bar":
        return (
            f"{head}\n⏸ אין נר חדש לסריקה (חג, נתונים מעוכבים או הרצה לפני סגירה).\n"
            f"נר אחרון: {_e(meta.get('session_date'))} | צפוי: {_e(meta.get('expected_session_date'))}\n"
            "לא נרשמו אותות."
        )
    if status == "benchmark_unavailable":
        return f"{head}\n⛔ לא התקבלו נתוני {_e(config.RS_BENCHMARK)}. הסריקה לא רצה. בדוק את מקור הנתונים."

    signals = [r for r in results if r.get("approved_signal")]
    live = [r for r in results if r.get("approved_live")]
    tier_a = [r for r in results if r.get("catalyst_tier") == "A"]
    lines = [
        head,
        f"נסרקו {meta.get('scanned', 0)} | עברו טכני: {meta.get('passed_technical', 0)} | "
        f"Tier A: {len(tier_a)} | אות (approved_signal): {len(signals)} | לביצוע: {len(live)}",
    ]
    if signals and not live:
        reasons = Counter(r.get("reason") for r in signals)
        lines.append("⚠️ <b>אות בלבד, לא לביצוע</b> | סיבה: " +
                     ", ".join(f"{_e(k)} ×{v}" for k, v in reasons.items()))
    elif not signals:
        lines.append("אין אותות היום.")
    for r in signals[:10]:
        lines.append(f"• {_e(r['ticker'])} ${_e(r['price'])} | cost_ratio={_e(r.get('cost_ratio'))} | {_e(r.get('reason'))}")

    warns = []
    if meta.get("mcap_missing_pct", 0) > config.MCAP_MISSING_ALERT_PCT:
        warns.append(f"mcap/float חסרים ב-{meta['mcap_missing_pct']}% מהטיקרים (fail-closed דוחה אותם)")
    if meta.get("fetch_errors", 0):
        warns.append(f"{meta['fetch_errors']} טיקרים נכשלו בשליפה")
    if meta.get("stale_bars", 0):
        warns.append(f"{meta['stale_bars']} טיקרים עם נר ישן")
    if any(r.get("classifier_source") == "keyword_fallback" for r in results):
        warns.append("סיווג קטליזטור עבר ל-keyword fallback (לא מאושר)")
    if config.COMMISSION_PER_SIDE is None:
        warns.append("COMMISSION_PER_SIDE לא מוגדר")
    if warns:
        lines.append("🚨 " + " | ".join(warns))
    return "\n".join(lines)


def send_run_summary(meta: dict, results: list):
    send_telegram_message(format_run_summary(meta, results))
    for t in [r for r in results if r.get("approved_live")]:
        send_telegram_message(format_trade_alert(t))


def send_error(text: str):
    send_telegram_message(f"❌ <b>שגיאה בריצת המערכת</b>\n{_e(text)[:1500]}")
