"""
כל הפרמטרים של המערכת - כאן מכוונים את ההתנהגות בלי לגעת בלוגיקה.

גרסה: v3.0-p0
כללי הניסוי (קפואים עד N אותות Tier A סגורים - ראה מסמך ההעברה):
  Tier A בלבד | כניסה ב-Open של T+1 | סטופ 4% | יעד 12% | חלון 3 ימים
  שער עלות במקום שער R:R | fail-closed ל-mcap/float
"""
import os

STRATEGY_VERSION = "v3.0-p0"

# --- יקום מניות לסריקה ---
UNIVERSE = [
    "SIRI", "SOFI", "PLUG", "F", "NOK", "RIOT", "MARA", "CHPT",
    "LCID", "NIO", "PLTR", "AAL", "CCL", "WBD", "PARA", "VALE",
]
UNIVERSE_FILE = "universe.csv"

PRICE_MIN = 5.0
PRICE_MAX = 30.0
MIN_AVG_VOLUME = 500_000          # לא בשימוש בסינון (נשמר לתאימות)
MIN_DOLLAR_VOLUME = 10_000_000    # מחזור x מחיר - הפילטר האמיתי לנזילות

# --- פילטרי Market Cap / Float ---
MARKET_CAP_MIN = 50_000_000
MARKET_CAP_MAX = 2_000_000_000
FLOAT_MIN = 10_000_000
FLOAT_MAX = 150_000_000
FAIL_CLOSED_MCAP_FLOAT = True     # חסר mcap/float = דחייה (missing_mcap_or_float)
MCAP_MISSING_ALERT_PCT = 20.0     # התראה בטלגרם אם יותר מ-X% מהטיקרים בלי mcap/float

# --- Gap Filter ---
GAP_MIN_PCT = 0.05
GAP_MAX_PCT = 0.25
GAP_REQUIRE_POSITIVE = True

# --- סוכן טכני ---
EMA_FAST = 9
EMA_SLOW = 21
EMA_TREND = 20
RSI_PERIOD = 14
RSI_MIN = 55
RSI_MAX = 70
RVOL_THRESHOLD = 3.0
ATR_PERIOD = 14
ATR_MIN_PCT = 0.02
ATR_MAX_PCT = 0.15

# --- Relative Strength ---
RS_BENCHMARK = "SPY"
RS_MIN_OUTPERFORMANCE = 0.02

# --- סשן שוק ---
MARKET_CLOSE_BUFFER_MIN = 20      # הנר נחשב סגור 16:00 NY + דקות אלה

# --- סוכן חדשות (Catalyst Agent) ---
LLM_PROVIDER = "gemini"           # "gemini" או "groq"
GEMINI_MODEL = "gemini-2.5-flash"
GROQ_MODEL = "llama-3.3-70b-versatile"
NEWS_LOOKBACK_HOURS = 24
REQUIRE_NEWS = True

CATALYST_TIER_MIN_ACCEPTABLE = "A"   # רק A מאושר. B/C/D נרשמים ונמדדים (shadow)
ALLOW_FALLBACK_APPROVAL = False      # סיווג keyword (בלי LLM) לא מאושר

CATALYST_KEYWORDS_TIER_A = [
    "fda approval", "fda clearance", "earnings beat", "raises guidance",
    "major contract", "acquisition", "merger", "buyout", "patent granted",
]
CATALYST_KEYWORDS_TIER_B = [
    "partnership", "collaboration", "new product launch", "analyst upgrade",
    "price target raised", "expands", "strategic",
]
CATALYST_KEYWORDS_TIER_C = [
    "press release", "announces", "update", "conference", "webinar",
]

# --- תוכנית עסקה (משותף ל-live / backtest / outcomes דרך agents/trade_plan.py) ---
HOLDING_DAYS_MIN = 1
HOLDING_DAYS_MAX = 3
STOP_LOSS_PCT = 0.04
TAKE_PROFIT_LIVE_PCT = 0.12
ENTRY_BASIS = "next_open"

TOTAL_BUDGET = 1000

# החלטה פתוחה (ראה מסמך): בפועל תקרת 35% חותכת את הסיכון ל~$14.
RISK_PER_TRADE_PCT = 0.02
RISK_PER_TRADE_DOLLARS = TOTAL_BUDGET * RISK_PER_TRADE_PCT
MAX_POSITION_VALUE_PCT = 0.35
MAX_OPEN_POSITIONS = 2
RANK_RULE = ("rvol_desc", "rs_desc", "ticker_asc")

# --- עלויות ---
# חובה להגדיר מהברוקר. None = אין approved_live (המדידה approved_signal ממשיכה).
COMMISSION_PER_SIDE = None
MAX_COST_RATIO = 0.25             # קבוע. לא מכווננים אותו כדי שהשער יעבור
SLIPPAGE_ENTRY_PCT = 0.0015       # הנחות פתיחה - להחליף בערכים מ-fills.csv
SLIPPAGE_STOP_PCT = 0.0025
SLIPPAGE_TP_PCT = 0.0010
CAPITAL_GAINS_TAX_RATE = 0.25     # לדוח בלבד (על סך הרווח בתקופה), לא בשער האישור

# --- קבצי לוג ---
LOG_FILE = "logs/decisions.csv"
SCREENER_ALL_FILE = "logs/screener_all.csv"
RUNS_FILE = "logs/runs.csv"
MCAP_SNAPSHOT_FILE = "logs/mcap_snapshot.csv"
FILLS_FILE = "logs/fills.csv"
LLM_RAW_DIR = "logs/llm_raw"
LEGACY_LOG_FILE = "logs/decisions_legacy_v2_buggy.csv"
