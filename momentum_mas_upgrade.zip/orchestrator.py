"""
Orchestrator: Screener -> Catalyst -> Risk -> לוגים + Telegram

קבצי לוג (כולם נשמרים ל-repo ע"י ה-workflow):
  logs/decisions.csv       אותות שעברו Screener (כולל נדחי Tier/עלות/קיבולת), dedupe לפי signal_date+ticker
  logs/screener_all.csv    כל הטיקרים בכל ריצה, עם all_failed (לבדיקת תרומת פילטרים)
  logs/runs.csv            שורה לכל ריצה (גם "אין אותות" וגם כישלונות)
  logs/mcap_snapshot.csv   snapshot יומי של mcap/float (לא ניתן לשחזר בדיעבד)
משתנה סביבה FORCE_RUN=1: עוקף בדיקת סשן/כפילות (בדיקות בלבד; run_mode=force).
"""
import os
import traceback
from datetime import datetime, timezone

from dotenv import load_dotenv

load_dotenv()

import config
from agents.catalyst_agent import run_catalyst_agent
from agents.risk_manager import run_risk_manager
from agents.screener_agent import prepare_session, run_screener_full
from notifier import send_error, send_run_summary
from utils import append_rows, load_universe, read_header, read_rows

DECISION_FIELDS = [
    "run_id", "run_mode", "timestamp_utc", "signal_date", "ticker", "strategy_version",
    "approved_signal", "approved_live", "reason", "skipped_capacity", "cost_gate_pass",
    "price", "rsi", "rvol", "atr_pct", "dollar_volume_m", "market_cap_m", "float_m",
    "gap_pct", "relative_strength_pct", "benchmark_change_pct", "mcap_missing", "float_missing",
    "catalyst_tier", "catalyst_type", "confidence", "classifier_source",
    "llm_provider", "llm_model", "prompt_hash", "news_count",
    "entry_basis", "entry_price_plan", "stop_loss_price", "take_profit_price", "take_profit_pct_used",
    "qty", "risk_dollars", "position_value", "cost_ratio", "rr_potential_gross", "stop_atr_ratio",
    "rank_position",
]
SCREENER_ALL_FIELDS = [
    "run_id", "signal_date", "ticker", "passed", "reject_reason", "all_failed",
    "price", "rsi", "rvol", "gap_pct", "atr_pct", "relative_strength_pct", "dollar_volume_m",
    "market_cap_m", "float_m", "mcap_missing", "float_missing", "fetch_error", "strategy_version",
]
RUN_FIELDS = [
    "run_id", "started_utc", "run_mode", "status", "session_date", "expected_session_date",
    "scanned", "fetch_errors", "stale_bars", "passed_technical", "tier_A",
    "approved_signal", "approved_live", "mcap_missing_pct", "commission_set",
    "strategy_version", "note",
]
SNAPSHOT_FIELDS = ["signal_date", "ticker", "market_cap", "float_shares", "mcap_missing", "float_missing",
                   "fetched_utc"]


def _iso(d):
    return d.isoformat() if hasattr(d, "isoformat") else ("" if d is None else str(d))


def _b(x):
    return "" if x is None else int(bool(x))


def _pct(x, mult=100.0, nd=2):
    return "" if x is None else round(x * mult, nd)


def session_already_processed(session_date) -> bool:
    for r in read_rows(config.RUNS_FILE):
        if r.get("run_mode") == "live" and r.get("status") == "ok" and r.get("session_date") == _iso(session_date):
            return True
    return False


def existing_decision_keys() -> set:
    header = read_header(config.LOG_FILE)
    if header != DECISION_FIELDS:
        return set()
    return {(r["signal_date"], r["ticker"], r["run_mode"]) for r in read_rows(config.LOG_FILE)}


def log_run(meta: dict, results: list, note: str = "") -> None:
    row = {
        "run_id": meta["run_id"], "started_utc": meta["started_utc"], "run_mode": meta["run_mode"],
        "status": meta.get("status"), "session_date": _iso(meta.get("session_date")),
        "expected_session_date": _iso(meta.get("expected_session_date")),
        "scanned": meta.get("scanned", 0), "fetch_errors": meta.get("fetch_errors", 0),
        "stale_bars": meta.get("stale_bars", 0), "passed_technical": meta.get("passed_technical", 0),
        "tier_A": sum(1 for r in results if r.get("catalyst_tier") == "A"),
        "approved_signal": sum(1 for r in results if r.get("approved_signal")),
        "approved_live": sum(1 for r in results if r.get("approved_live")),
        "mcap_missing_pct": meta.get("mcap_missing_pct", ""),
        "commission_set": int(config.COMMISSION_PER_SIDE is not None),
        "strategy_version": config.STRATEGY_VERSION, "note": note,
    }
    append_rows(config.RUNS_FILE, RUN_FIELDS, [row])


def log_screener_all(run_id: str, records: list) -> None:
    rows = []
    for r in records:
        mc, fl = r.get("market_cap"), r.get("float_shares")
        rows.append({
            "run_id": run_id, "signal_date": _iso(r.get("bar_date")), "ticker": r["ticker"],
            "passed": _b(r.get("passed")), "reject_reason": r.get("reject_reason") or "",
            "all_failed": ";".join(r.get("all_failed") or []),
            "price": "" if r.get("price") is None else round(r["price"], 2),
            "rsi": "" if r.get("rsi") is None else round(r["rsi"], 1),
            "rvol": "" if r.get("rvol") is None else round(r["rvol"], 2),
            "gap_pct": _pct(r.get("gap_pct")), "atr_pct": _pct(r.get("atr_pct")),
            "relative_strength_pct": _pct(r.get("relative_strength")),
            "dollar_volume_m": "" if r.get("dollar_volume") is None else round(r["dollar_volume"] / 1e6, 1),
            "market_cap_m": "" if mc is None else round(mc / 1e6, 1),
            "float_m": "" if fl is None else round(fl / 1e6, 1),
            "mcap_missing": _b(r.get("mcap_missing")), "float_missing": _b(r.get("float_missing")),
            "fetch_error": r.get("fetch_error") or "", "strategy_version": config.STRATEGY_VERSION,
        })
    append_rows(config.SCREENER_ALL_FILE, SCREENER_ALL_FIELDS, rows)


def log_mcap_snapshot(records: list) -> None:
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    rows = [{
        "signal_date": _iso(r.get("bar_date")), "ticker": r["ticker"],
        "market_cap": "" if r.get("market_cap") is None else r["market_cap"],
        "float_shares": "" if r.get("float_shares") is None else r["float_shares"],
        "mcap_missing": _b(r.get("mcap_missing")), "float_missing": _b(r.get("float_missing")),
        "fetched_utc": now,
    } for r in records if r.get("bar_date") is not None]
    append_rows(config.MCAP_SNAPSHOT_FILE, SNAPSHOT_FIELDS, rows)


def log_decisions(run_id: str, run_mode: str, results: list) -> int:
    keys = existing_decision_keys()
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    rows = []
    for r in results:
        sd = _iso(r.get("bar_date"))
        if (sd, r["ticker"], run_mode) in keys:
            print(f"  (כפילות מדולגת: {r['ticker']} {sd})")
            continue
        row = {k: r.get(k, "") for k in DECISION_FIELDS}
        row.update({
            "run_id": run_id, "run_mode": run_mode, "timestamp_utc": now, "signal_date": sd,
            "approved_signal": int(bool(r.get("approved_signal"))),
            "approved_live": int(bool(r.get("approved_live"))),
            "cost_gate_pass": "" if r.get("cost_gate_pass") is None else int(bool(r["cost_gate_pass"])),
            "skipped_capacity": int(r.get("skipped_capacity", 0)),
        })
        for k in DECISION_FIELDS:
            if row.get(k) is None:
                row[k] = ""
        rows.append(row)
    append_rows(config.LOG_FILE, DECISION_FIELDS, rows, legacy_path=config.LEGACY_LOG_FILE)
    return len(rows)


def run_pipeline(meta: dict) -> list:
    force = meta["run_mode"] == "force"
    universe = load_universe()

    session = prepare_session(enforce_session=not force)
    meta.update(session)
    print(f"נר: {session['session_date']} | צפוי: {session['expected_session_date']} | סטטוס: {session['status']}")

    if meta["status"] != "ok":
        log_run(meta, [], note="session_check_failed")
        send_run_summary(meta, [])
        return []

    if not force and session_already_processed(meta["session_date"]):
        print("הנר הזה כבר נסרק (live). יוצא בלי לכתוב.")
        return []

    print(f"\n[סוכן 1/3] Screener - סורק {len(universe)} מניות...")
    candidates, records, counts = run_screener_full(universe, meta["benchmark_change"], meta["session_date"])
    meta.update(counts)
    log_screener_all(meta["run_id"], records)
    log_mcap_snapshot(records)
    print(f"  --> {len(candidates)} עברו סינון טכני")

    results = []
    if candidates:
        print("\n[סוכן 2/3] Catalyst Agent...")
        enriched = run_catalyst_agent(candidates, run_id=meta["run_id"], bar_date=meta["session_date"])
        print("\n[סוכן 3/3] Risk Manager...")
        results = run_risk_manager(enriched)
        n = log_decisions(meta["run_id"], meta["run_mode"], results)
        print(f"  נרשמו {n} שורות ל-{config.LOG_FILE}")
    else:
        print("אין מועמדות היום.")

    log_run(meta, results, note="ok")
    send_run_summary(meta, results)
    return results


def main():
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    force = os.getenv("FORCE_RUN") == "1"
    meta = {
        "run_id": run_id,
        "run_mode": "force" if force else "live",
        "started_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    print("=" * 70)
    print(f"Momentum MAS {config.STRATEGY_VERSION} | run {run_id} | mode={meta['run_mode']}")
    print("=" * 70)
    try:
        results = run_pipeline(meta)
        approved = sum(1 for r in results if r.get("approved_live"))
        signals = sum(1 for r in results if r.get("approved_signal"))
        print("=" * 70)
        print(f"סיכום: אותות={signals} | לביצוע={approved}")
        print("=" * 70)
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        meta["status"] = "error"
        try:
            log_run(meta, [], note=f"error:{e}"[:200])
        except Exception:  # noqa: BLE001
            pass
        send_error(f"{type(e).__name__}: {e}")
        raise


if __name__ == "__main__":
    main()
