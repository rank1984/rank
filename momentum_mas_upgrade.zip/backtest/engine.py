"""
Backtest Engine (P0-4): אותה תוכנית עסקה כמו ה-live (agents/trade_plan.py), כניסה ב-Open של T+1.

DESCRIPTIVE_ONLY - אין בו Tier A (אין חדשות היסטוריות), יש survivorship bias ביקום,
ופילטרי mcap/float לא נקודתיים (לכן לא נבדקים כאן). אינו ראיה ל-Edge.

R = qty * (entry_fill - stop). pnl ברוטו כולל slippage ולא כולל עמלה.
"""
import pandas as pd
import yfinance as yf

import config
from agents.filters import add_indicators, evaluate_filters, features_at
from agents.trade_plan import plan_trade
from utils import load_universe

WARMUP_BARS = 30


def get_historical_data(tickers: list, start: str, end: str) -> dict:
    """מוריד נתונים יומיים לכל הטיקרים + SPY"""
    print(f"מוריד נתונים היסטוריים מ-{start} עד {end}...")
    data = {}
    spy = yf.download(config.RS_BENCHMARK, start=start, end=end, progress=False, auto_adjust=True)
    if isinstance(spy.columns, pd.MultiIndex):
        spy.columns = spy.columns.get_level_values(0)
    data["SPY"] = spy

    for i, ticker in enumerate(tickers):
        try:
            df = yf.download(ticker, start=start, end=end, progress=False, auto_adjust=True)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if len(df) > 50:
                data[ticker] = df
        except Exception:  # noqa: BLE001
            pass
        if (i + 1) % 20 == 0:
            print(f"  הורדו {i + 1}/{len(tickers)} טיקרים...")
    print(f"נטענו בהצלחה {len(data) - 1} מניות + SPY")
    return data


def screen_on_date(ticker: str, df_ind: pd.DataFrame, pos: int, spy_change: float):
    """פילטרים טכניים בלבד (בלי mcap/float - אין נתון נקודתי) על נר במיקום pos"""
    f = features_at(df_ind, pos, spy_change)
    if f is None:
        return None
    if evaluate_filters(f, check_mcap_float=False):
        return None
    return {
        "ticker": ticker,
        "date": pd.Timestamp(df_ind.index[pos]),
        "price": round(f["price"], 2),
        "rsi": round(f["rsi"], 1),
        "rvol": round(f["rvol"], 2),
        "gap_pct": round(f["gap_pct"] * 100, 2),
        "relative_strength_pct": round(f["relative_strength"] * 100, 2),
        "atr_pct": round(f["atr_pct"] * 100, 2),
    }


def simulate_trade(candidate: dict, df: pd.DataFrame, hold_days: int | None = None,
                   slip_entry: float | None = None, slip_stop: float | None = None,
                   slip_tp: float | None = None) -> dict:
    """
    כניסה ב-Open של יום המסחר אחרי האות. חלון כולל את יום הכניסה.
    סדר באותו נר: סטופ לפני יעד. פער בפתיחה: סטופ min(open, stop), יעד max(open, tp).
    status: closed | pending (אין עדיין נרות מספיקים) | no_size
    """
    hold_days = hold_days or config.HOLDING_DAYS_MAX
    slip_entry = config.SLIPPAGE_ENTRY_PCT if slip_entry is None else slip_entry
    slip_stop = config.SLIPPAGE_STOP_PCT if slip_stop is None else slip_stop
    slip_tp = config.SLIPPAGE_TP_PCT if slip_tp is None else slip_tp

    pos = df.index.get_loc(candidate["date"])
    if pos + 1 >= len(df):
        return {"status": "pending"}

    window = df.iloc[pos + 1: pos + 1 + hold_days]
    entry = float(window.iloc[0]["Open"]) * (1 + slip_entry)
    plan = plan_trade(entry)
    if plan is None:
        return {"status": "no_size"}
    stop, tp, qty = plan["stop_loss_price"], plan["take_profit_price"], plan["qty"]

    exit_price = exit_reason = exit_date = None
    mae = mfe = 0.0
    days_held = 0
    for i, (dt, row) in enumerate(window.iterrows()):
        o, h, l, c = (float(row[k]) for k in ("Open", "High", "Low", "Close"))
        days_held = i + 1
        mae = min(mae, l / entry - 1)
        mfe = max(mfe, h / entry - 1)

        if i > 0 and o <= stop:
            exit_price, exit_reason = o * (1 - slip_stop), "stop_gap"
        elif l <= stop:
            exit_price, exit_reason = stop * (1 - slip_stop), "stop_loss"
        elif i > 0 and o >= tp:
            exit_price, exit_reason = o * (1 - slip_tp), "take_profit_gap"
        elif h >= tp:
            exit_price, exit_reason = tp * (1 - slip_tp), "take_profit"
        elif i == len(window) - 1:
            if len(window) < hold_days:
                return {"status": "pending"}
            exit_price, exit_reason = c, "time_exit"

        if exit_reason:
            exit_date = dt
            break

    if exit_price is None:
        return {"status": "pending"}

    risk_dollars = plan["risk_dollars"]
    pnl_gross = qty * (exit_price - entry)
    comm = config.COMMISSION_PER_SIDE
    pnl_net = None if comm is None else pnl_gross - 2 * comm

    return {
        "status": "closed",
        "ticker": candidate["ticker"],
        "signal_date": pd.Timestamp(candidate["date"]).strftime("%Y-%m-%d"),
        "entry_date": pd.Timestamp(window.index[0]).strftime("%Y-%m-%d"),
        "exit_date": pd.Timestamp(exit_date).strftime("%Y-%m-%d"),
        "signal_close": candidate["price"],
        "entry_gap_vs_signal_close_pct": round((entry / candidate["price"] - 1) * 100, 2),
        "entry_price": round(entry, 4),
        "stop": stop,
        "take_profit": tp,
        "exit_price": round(exit_price, 4),
        "exit_reason": exit_reason,
        "qty": qty,
        "days_held": days_held,
        "risk_dollars_R": risk_dollars,
        "pnl_gross": round(pnl_gross, 2),
        "pnl_net_commission": None if pnl_net is None else round(pnl_net, 2),
        "r_multiple_gross": round(pnl_gross / risk_dollars, 3) if risk_dollars else 0.0,
        "r_multiple_net": None if pnl_net is None or not risk_dollars else round(pnl_net / risk_dollars, 3),
        "mae_pct": round(mae * 100, 2),
        "mfe_pct": round(mfe * 100, 2),
        "slippage_bps": round(slip_entry * 1e4, 1),
        "rvol": candidate["rvol"],
        "relative_strength_pct": candidate["relative_strength_pct"],
        "rsi": candidate["rsi"],
        "gap_pct": candidate["gap_pct"],
        "atr_pct": candidate["atr_pct"],
    }


def mark_portfolio_selection(trades: list) -> list:
    """
    שכבת פורטפוליו: MAX_OPEN_POSITIONS, כלל בחירה (RVOL יורד, RS יורד, טיקר).
    פוזיציה נחשבת תפוסה עד יום היציאה (כולל) - שמרני.
    """
    ordered = sorted(
        trades,
        key=lambda t: (t["entry_date"], -float(t["rvol"]), -float(t["relative_strength_pct"]), t["ticker"]),
    )
    open_positions = []  # (ticker, exit_date)
    for t in ordered:
        open_positions = [(tk, ex) for tk, ex in open_positions if ex >= t["entry_date"]]
        if len(open_positions) < config.MAX_OPEN_POSITIONS:
            t["portfolio_selected"] = 1
            open_positions.append((t["ticker"], t["exit_date"]))
        else:
            t["portfolio_selected"] = 0
    return ordered


def run_backtest(start_date: str, end_date: str, data: dict | None = None, sensitivity: float = 1.0) -> list:
    """
    unit-level: כל אות טכני מדומה, פוזיציה פתוחה באותו טיקר חוסמת אות חדש.
    portfolio_selected=1 לעסקאות שנכנסות עם MAX_OPEN_POSITIONS וכלל הבחירה.
    sensitivity: מכפיל ל-slippage (1, 2, 3).
    """
    if data is None:
        data = get_historical_data(load_universe(), start_date, end_date)
    if "SPY" not in data:
        print("שגיאה: לא הצלחנו להוריד את SPY")
        return []

    spy = data["SPY"]
    spy_change = spy["Close"].pct_change()
    dates = [d for i, d in enumerate(spy.index) if i >= WARMUP_BARS]

    indicators, index_pos = {}, {}
    for ticker, df in data.items():
        if ticker == "SPY":
            continue
        ind = add_indicators(df)
        indicators[ticker] = ind
        index_pos[ticker] = {d: i for i, d in enumerate(ind.index)}

    se, ss, st = (config.SLIPPAGE_ENTRY_PCT * sensitivity, config.SLIPPAGE_STOP_PCT * sensitivity,
                  config.SLIPPAGE_TP_PCT * sensitivity)
    busy_until = {}
    trades = []
    for date in dates:
        sc = spy_change.get(date)
        if sc is None or pd.isna(sc):
            continue
        for ticker, ind in indicators.items():
            pos = index_pos[ticker].get(date)
            if pos is None:
                continue
            cand = screen_on_date(ticker, ind, pos, float(sc))
            if not cand:
                continue
            if ticker in busy_until and date <= busy_until[ticker]:
                continue
            res = simulate_trade(cand, data[ticker], slip_entry=se, slip_stop=ss, slip_tp=st)
            if res["status"] != "closed":
                continue
            busy_until[ticker] = pd.Timestamp(res["exit_date"])
            trades.append(res)

    return mark_portfolio_selection(trades)
