"""
הרצת Backtest (DESCRIPTIVE_ONLY). להריץ מתיקיית השורש:
    python -m backtest.run_backtest --days 365 --sens 1 2 3
"""
import argparse
import os
from datetime import datetime, timedelta

import pandas as pd

import config
from backtest.engine import run_backtest
from backtest.metrics import breakdown, calculate_metrics
from backtest.stats import bootstrap_ci_mean

BANNER = "DESCRIPTIVE_ONLY - אין Tier A, יש survivorship, mcap/float לא נקודתיים. לא ראיה ל-Edge."


def _report(name: str, df: pd.DataFrame) -> None:
    print(f"\n--- {name} ---")
    if df.empty:
        print("אין עסקאות.")
        return
    d = df.copy()
    d["r_multiple"] = d["r_multiple_gross"]
    d["bars_held"] = d["days_held"]
    m = calculate_metrics(d)
    ci = bootstrap_ci_mean(d["r_multiple"].tolist())
    print(f"עסקאות: {m['total_trades']} | Win rate: {m['win_rate']:.1%} | Expectancy (R ברוטו): {m['expectancy_r']:.3f}")
    print(f"Avg win R: {m['avg_win_r']:.2f} | Avg loss R: {m['avg_loss_r']:.2f} | "
          f"Max DD (R): {m['max_drawdown_r']:.2f} | רצף הפסדים: {m['longest_losing_streak']}")
    if ci:
        print(f"Expectancy 90% CI (bootstrap): [{ci[0]:.3f}, {ci[2]:.3f}]")
    print("יציאות:", d["exit_reason"].value_counts().to_dict())
    print(f"gap ממוצע בין סגירת האות לכניסה: {d['entry_gap_vs_signal_close_pct'].mean():.2f}%")
    bd = breakdown(d, "exit_reason")
    if not bd.empty:
        print(bd.to_string())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=365)
    ap.add_argument("--sens", type=float, nargs="+", default=[1.0], help="מכפילי slippage, למשל 1 2 3")
    args = ap.parse_args()

    end = datetime.now()
    start = end - timedelta(days=args.days)
    s, e = start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")
    print("=" * 60)
    print(f"Momentum MAS {config.STRATEGY_VERSION} - Backtest | {s} -> {e}")
    print(BANNER)
    print("=" * 60)

    from backtest.engine import get_historical_data
    from utils import load_universe
    data = get_historical_data(load_universe(), s, e)

    os.makedirs("logs", exist_ok=True)
    for sens in args.sens:
        trades = run_backtest(s, e, data=data, sensitivity=sens)
        df = pd.DataFrame(trades)
        print(f"\n===== slippage x{sens} =====")
        _report("unit-level", df)
        if not df.empty:
            _report("portfolio-level (MAX_OPEN_POSITIONS)", df[df["portfolio_selected"] == 1])
            df.to_csv(f"logs/backtest_trades_sens{sens:g}.csv", index=False)
    print("\n" + BANNER)


if __name__ == "__main__":
    main()
