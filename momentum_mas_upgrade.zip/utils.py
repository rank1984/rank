"""
כלי עזר: טעינת יקום, שעון שוק (NY), וכתיבת CSV עם מיגרציית כותרות.
"""
import csv
import os
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

import pandas as pd

import config

NY = ZoneInfo("America/New_York")


# ---------- יקום ----------
def load_universe() -> list:
    """טוען יקום מניות מ-CSV אם קיים (בלי כפילויות, לפי סדר), אחרת config.UNIVERSE"""
    if os.path.exists(config.UNIVERSE_FILE):
        try:
            df = pd.read_csv(config.UNIVERSE_FILE)
            raw = df["ticker"].dropna().astype(str).str.upper().str.strip().tolist()
            tickers = list(dict.fromkeys(t for t in raw if t))
            dupes = len(raw) - len(tickers)
            msg = f"נטענו {len(tickers)} טיקרים מ-{config.UNIVERSE_FILE}"
            if dupes:
                msg += f" (הוסרו {dupes} כפילויות)"
            print(msg)
            return tickers
        except Exception as e:
            print(f"שגיאה בטעינת {config.UNIVERSE_FILE}: {e}. משתמש ב-UNIVERSE ברירת מחדל.")
            return list(dict.fromkeys(config.UNIVERSE))
    return list(dict.fromkeys(config.UNIVERSE))


# ---------- שעון שוק ----------
def ny_now() -> datetime:
    return datetime.now(NY)


def expected_session_date(now_ny: datetime | None = None) -> date:
    """
    תאריך הנר היומי הסגור האחרון שצפוי להיות זמין:
    - אחרי הסגירה (16:00 NY + buffer) ביום חול: היום
    - לפני הסגירה / סוף שבוע: יום החול הקודם
    ימי חג לא מוכרים כאן: ביום חג הנר האחרון קודם לתאריך הצפוי -> הריצה נעצרת (no_new_bar).
    """
    now_ny = now_ny or ny_now()
    d = now_ny.date()
    ready = now_ny.time() >= time(16, config.MARKET_CLOSE_BUFFER_MIN)
    if now_ny.weekday() >= 5 or not ready:
        d = d - timedelta(days=1)
    while d.weekday() >= 5:
        d = d - timedelta(days=1)
    return d


# ---------- CSV ----------
def read_rows(path: str) -> list:
    if not os.path.isfile(path):
        return []
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def read_header(path: str):
    if not os.path.isfile(path):
        return None
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.reader(f)
        return next(r, None)


def append_rows(path: str, fieldnames: list, rows: list, legacy_path: str | None = None) -> None:
    """
    מוסיף שורות ל-CSV. אם קיים קובץ עם כותרת שונה - הוא מועבר ל-legacy_path
    (או נשמר עם סיומת _legacy_<timestamp>) והקובץ החדש מתחיל נקי.
    """
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)

    header = read_header(path)
    if header is not None and header != fieldnames:
        target = legacy_path or f"{path}.legacy_{datetime.utcnow().strftime('%Y%m%dT%H%M%S')}"
        if os.path.exists(target):
            target = f"{target}.{datetime.utcnow().strftime('%Y%m%dT%H%M%S')}"
        os.replace(path, target)
        print(f"  [מיגרציה] {path} עם כותרת ישנה הועבר ל-{target}")

    exists = os.path.isfile(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        if not exists:
            w.writeheader()
        for r in rows:
            w.writerow(r)
